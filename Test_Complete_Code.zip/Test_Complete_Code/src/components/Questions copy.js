import React, { useState, useEffect } from 'react';
import { QUESTIONS } from '../questions';
import axios from 'axios';

const Questions = () => {
  const [responses, setResponses] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [currentScore, setCurrentScore] = useState(0);
  const [averageScore, setAverageScore] = useState(0);

  useEffect(() => {
    const fetchScores = async () => {
      try {
        const response = await axios.get('http://localhost:5000/scores');
        const scores = response.data;
        const totalScore = scores.reduce((total, score) => total + score, 0);
        const avgScore = totalScore / scores.length || 0;
        setAverageScore(avgScore);
      } catch (error) {
        console.error('Error fetching scores:', error);
      }
    };
    fetchScores();
  }, []);

  const handleResponse = (index, answer) => {
    setResponses(prev => ({ ...prev, [index]: answer }));
  };

  const handleSubmit = async () => {
    const yesCount = Object.values(responses).filter(response => response === 'yes').length;
    const score = (100 * yesCount) / Object.keys(QUESTIONS).length;
    setCurrentScore(score);

    try {
      const response = await axios.post('http://localhost:5000/scores', { score });
      const scores = response.data;
      const totalScore = scores.reduce((total, score) => total + score, 0);
      const avgScore = totalScore / scores.length;
      setAverageScore(avgScore);
    } catch (error) {
      console.error('Error saving score:', error);
    }

    setSubmitted(true);
  };

  const handleRetakeQuiz = () => {
    setResponses({});
    setSubmitted(false);
    setCurrentScore(0);
  };

  if (submitted) {
    return (
      <div className="qa-form">
        <h2>Your Score: {currentScore.toFixed(2)}</h2>
        <h2>Average Score: {averageScore.toFixed(2)}</h2>
        <button onClick={handleRetakeQuiz}>Retake Quiz</button>
      </div>
    );
  }
  
  return (
    <div className="qa-form">
      {Object.entries(QUESTIONS).map(([index, question]) => (
        <div  className="form-group" key={index}>
          <label>{question}</label>
          <div className="form-field">
            <button 
              onClick={() => handleResponse(index, 'yes')} 
              className={responses[index] === 'yes' ? 'selected' : ''}
            >
              Yes
            </button>
            <button 
              onClick={() => handleResponse(index, 'no')} 
              className={responses[index] === 'no' ? 'selected' : ''}
            >
              No
            </button>
          </div>
        </div>
      ))}
      <div className="action-button">
      <button onClick={handleSubmit} disabled={Object.keys(responses).length !== Object.keys(QUESTIONS).length}>Submit</button>
      </div>
    </div>
  );
};

export default Questions;
