// Questions.js

import React from 'react';

const Questions = ({ question, handleAnswer }) => {
  return (
    <>
        <label className="question-text">{question}</label>
      <div className="answer-buttons">
        <button className="answer-button answer-button-yes" onClick={() => handleAnswer('Yes')}>Yes</button>
        <button className="answer-button answer-button-no" onClick={() => handleAnswer('No')}>No</button>
      </div>
    </>
  );
};

export default Questions;
