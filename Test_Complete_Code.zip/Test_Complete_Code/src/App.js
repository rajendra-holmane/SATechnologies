import React, { useState, useEffect } from 'react';
import Questions from './components/Questions';
import { QUESTIONS } from './questions';
import './App.css';

const calculateScore = (answers) => {
  const numberOfYes = Object.values(answers).filter(answer => answer === 'Yes').length;
  return (numberOfYes / Object.keys(QUESTIONS).length) * 100;
};

function App() {
  const [questionIds, setQuestionIds] = useState([]);
  const [answers, setAnswers] = useState({});
  const [score, setScore] = useState(0);
  const [allRunsScores, setAllRunsScores] = useState([]);

  useEffect(() => {
    setQuestionIds(Object.keys(QUESTIONS).map(Number));
  }, []);

  const handleAnswer = (answer) => {
    const currentQuestionId = questionIds[0];
    setAnswers({ ...answers, [currentQuestionId]: answer });

    const remainingQuestionIds = questionIds.slice(1);
    setQuestionIds(remainingQuestionIds);

    if (remainingQuestionIds.length === 0) {
      const currentScore = calculateScore(answers);
      setScore(currentScore);
      setAllRunsScores([...allRunsScores, currentScore]);
    }
  };

  const restartQuiz = () => {
    setQuestionIds(Object.keys(QUESTIONS).map(Number));
    setAnswers({});
    setScore(0);
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1 className="title">Welcome to the Quiz</h1>
      </header>
      <main className="main-content">
        <div className="question-container">
          {questionIds.length > 0 && (
            <Questions 
              question={QUESTIONS[questionIds[0]]}
              handleAnswer={handleAnswer}
            />
          )}
          {(questionIds.length === 0 || Object.keys(answers).length === Object.keys(QUESTIONS).length) && (
            <div className="score">
              <h2>Score: {score.toFixed(2)}%</h2>
              {allRunsScores.length > 0 && (
                <>
                  <h3>Average Rating:</h3>
                  <h2>
                    {score <= 40 && "Your performance is poor."}
                    {score > 40 && score <= 70 && "Your performance is average."}
                    {score > 70 && "Your performance is excellent!"}
                  </h2>
                </>
              )}
              <button onClick={restartQuiz}>Restart Quiz</button>
            </div>
          )}
        </div>
      </main>
      <footer className="footer">       
        <p>Powered by React</p>
      </footer>
    </div>
  );
}

export default App;
