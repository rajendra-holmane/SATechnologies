const express = require('express');
const storage = require('node-persist');
const cors = require('cors');

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

// Initialize storage
(async () => {
    await storage.init();
})();

// Endpoint to get scores
app.get('/scores', async (req, res) => {
    const scores = (await storage.getItem('scores')) || [];
    res.json(scores);
});

// Endpoint to add a new score
app.post('/scores', async (req, res) => {
    const newScore = req.body.score;
    const scores = (await storage.getItem('scores')) || [];
    scores.push(newScore);
    await storage.setItem('scores', scores);
    res.json(scores);
});

// Handle the root path
app.get('/', (req, res) => {
    res.send('Backend server is running');
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});